from requests import Session


class JiraAPI(object):
	r"""Manage interactions with JIRA server

	   :param server: hostname or ip where JIRA is
	   :param credentials: is a tuple containing username and password
	"""
	def __init__(self, server, credentials):
		self._api = server
		self._http = Session()
		self._http.auth = credentials


	def get(self, endpoint, key=None):
		r"""Sends a GET request to JIRA server

		:param endpoint: URL path that will be issued
		:param key: (optional) issue identifier
		"""
		url = self._api + endpoint
		if key:
			url += '/{}'.format(key)

		try:
			return self._http.get(url=url).json()
		except:
			return None


	def post(self, endpoint, payload):
		r"""Sends a POST request to JIRA server

		:param endpoint: URL path that will be issued
		:param payload: Dictionary that will be send as a json in the body
		"""
		url = self._api + endpoint
		try:
			return self._http.post(url=url, json=payload)
		except:
			return None
