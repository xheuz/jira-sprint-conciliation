from .api import JiraAPI
from .models import Issue, CreateMeta, Filter
from .defaults import DESCRIPTION_TEMPLATE, SUMMARY_TEMPLATE
from .exceptions import CreateMetaNotFound

__all__ = ['jiralite']

class jiralite(object):
	r"""JIRA client interface

	:param server: hostname or ip where JIRA is
	:param credentials: is a tuple containing username and password
	"""
	def __init__(self, server, credentials):
		self._client = JiraAPI(server, credentials)


	def _createmeta(self):
		r"""Returns a CreateMeta JIRA object"""
		try:
			return CreateMeta(self._client.get(CreateMeta.get_endpoint()))
		except:
			raise CreateMetaNotFound()


	def issue(self, key):
		r"""Returns an Issue object or None if issue not found

		:param key: issue identifier
		"""
		try:
			return Issue(self._client.get(Issue.get_endpoint(), key))
		except:
			return None


	def filter(self, id):
		r"""Returns a Filter object or None if filter not found

		:param id: filter identifier
		"""
		try:
			filter_details = self._client.get(Filter.get_endpoint(), key)
			search = '/' + filter_details['searchUrl'].split('/')[-1]
			search += '&maxResults=1000'
			return Filter(self._client.get(search))
		except:
			return None


	def create_issue(self, project_key, summary, description, \
		issue_type="Task", assignee=None, parent_issue=None):
		r"""Creates an Issue in JIRA

		:param project_key: project identifier
		:param summary: issue subject
		:param description: issue description
		:param issue_type: (optional) default Task, if parent_issue is defined then default is Sub-task
		:param assignee: (optional) entity accountable for solving the issue. Must match account name
		:param parent_issue: (optional) Issue object where issue will be created as a Sub-task
		"""
		createmeta = self._createmeta()
		payload = {'fields' : {}}

		if parent_issue:
			project_key = parent_issue.project_id
			issue_type = "Sub-task"
			payload['fields']['parent'] = {"key": parent_issue.key}

		issue_type_id = createmeta.find_issue_type_id(project_key, issue_type)
		payload['fields']['description'] = description
		payload['fields']['summary'] = summary
		payload['fields']['project'] = {"key": project_key}
		payload['fields']['issuetype'] = {"id" : issue_type_id}
		payload['fields']['assignee'] = {"name": assignee}

		try:
			return self._client.post('/issue', payload)
		except Exception as e:
			return e
