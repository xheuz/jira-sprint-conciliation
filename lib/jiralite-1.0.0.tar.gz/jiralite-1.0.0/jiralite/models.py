from .utils import contains
from .exceptions import NoIssueDefinedError


class BaseModel(object):
	@classmethod
	def get_endpoint(cls):
		return cls.endpoint


	def _get(self, attribute=None):
		if not attribute:
			return None

		data = self._data
		for identifier in attribute.split("."):
			try:
				data = data.get(identifier)
			except AttributeError as e:
				return None
		return data



class Issue(BaseModel):

	endpoint = '/issue'

	def __init__(self, issue_data):
		self._data = issue_data
		self.id = self._get("id")
		self.key = self._get("key")
		self.summary = self._get("fields.summary")
		self.description = self._get("fields.description")
		self.issuetype_id = self._get("fields.issuetype.id")
		self.issuetype = self._get("fields.issuetype.name")
		self.subtasks = self._get("fields.subtasks")
		self.status = self._get("fields.status.name")
		self.project_id = self._get("fields.project.key")
		self.project = self._get("fields.project.name")
		self.assignee = self._get("fields.assignee.key")
		self.reporter = self._get("fields.reporter.key")
		self.creator = self._get("fields.creator.key")
		self.comments = self._get("fields.comment.comments")


	def has_subtask(self, summary):
		for subtask in self.subtasks:
			if contains(summary, subtask['fields']['summary']):
				return True
		return None



class CreateMeta(BaseModel):

	endpoint = '/issue/createmeta'

	def __init__(self, metadata):
		self._createmeta = metadata


	def find_issue_type_id(self, project_key, issue_type):
		for project in self._createmeta.get("projects"):
			if project["key"] == project_key:
				for issuetype in project.get("issuetypes"):
					if issuetype["name"] == issue_type:
						return issuetype["id"]
		return None



class Filter(BaseModel):
	
	endpoint = '/filter'

	def __init__(self, filter_data):
		self._data = filter_data
		self.issues = self._get("issues")
