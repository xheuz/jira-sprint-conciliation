DESCRIPTION_TEMPLATE = "*QA US Schema:* MMBUQA_USA_A2W_CAMPMANAGER\r\n\
*QA UK Schema:* MMBUQA_EU_PROD_CMPRO\r\n\r\n\
*run script(s):*\r\n{}\r\n\r\n\
*Only if requested, run revert script(s):*\r\n{}"

SUMMARY_TEMPLATE = "[DBA] Run SQL Script for {} in QA US and UK Databases"