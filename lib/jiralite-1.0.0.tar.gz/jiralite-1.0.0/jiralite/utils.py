import re

def contains(pattern, string):
	return re.search(pattern, string, re.IGNORECASE)