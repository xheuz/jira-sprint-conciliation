class NoIssueDefinedError(Exception):
	pass

class CreateMetaNotFound(Exception):
	pass